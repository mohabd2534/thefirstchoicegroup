# The First Choice Group — website

Production-ready, fully static implementation of the Claude Design prototypes
(`../project/*.dc.html`). Plain HTML/CSS/JS — **no build step, no framework, no
dependencies**. Open `index.html` in a browser or drop the folder onto any
static host.

## Pages

| File | Purpose |
|------|---------|
| `index.html` | Home — hero with live Instant Offer Estimator, situations, stats, how-it-works, why-us, testimonials |
| `estimator.html` | Full adaptive multi-step offer estimator |
| `foreclosure.html` · `repairs.html` · `probate.html` · `relocation.html` · `just-selling.html` | Situation / solution pages |
| `loan-programs.html` | Investor financing (fix-and-flip, bridge, rental) |
| `about.html` · `contact.html` · `faq.html` | Company pages |

## Shared code

- **`assets/styles.css`** — base styles, fonts, keyframes, responsive layout helpers.
- **`assets/site.js`** — injects the shared nav, footer, and 24/7 chat widget on
  every page; wires hover effects (`data-hover`) and the mobile nav. Each page
  just needs `<div id="site-nav"></div>`, `<div id="site-footer"></div>`, and
  `<script src="assets/site.js" defer></script>`.

## Local preview

```bash
cd site
python3 -m http.server 8000   # then open http://localhost:8000
```

## Deploy

Static files, so anything works (Vercel, Netlify, Hostinger, S3, GitHub Pages).
`vercel.json` enables clean URLs (`/foreclosure` instead of `/foreclosure.html`).

## What's still simulated (wire these to real services before relying on leads)

- **Estimator pricing** — a deterministic client-side model (see the `run()` /
  `result()` functions), not a live Zillow/ATTOM comp feed.
- **Chat widget** — scripted keyword answers in `assets/site.js` (`chatAnswer`),
  not a real AI service.
- **Lead capture** — the hero address bar stores leads in `localStorage`
  (`fc-crm-leads`), marked in `index.html` as the CRM sync point.
- **Contact form** — does not submit anywhere yet.
- **Photos** — lifestyle/team images are styled placeholders; drop in real images.
