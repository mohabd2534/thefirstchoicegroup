/* The First Choice Group — shared site chrome (nav, footer, chat widget)
   and behaviour (hover effects, mobile nav). No build step, no framework.
   Ported from the SiteNav / SiteFooter / ChatWidget design components. */
(function () {
  'use strict';

  var LOGO = 'https://thefirstchoicegroup.com/wp-content/uploads/2021/07/first-choice-1-109x62.png';

  var SITUATIONS = [
    ['just-selling.html', 'Just Looking to Sell'],
    ['foreclosure.html', 'Facing Foreclosure'],
    ['repairs.html', 'Too Many Repairs'],
    ['probate.html', 'Inherited &amp; Probate'],
    ['relocation.html', 'Relocation &amp; Divorce']
  ];

  /* -------------------------------------------------- hover effects
     Reproduces the design's `style-hover`: apply the given declarations on
     mouseenter, restore on mouseleave. Values are kept in the element's
     data-hover attribute as "prop:val;prop:val". */
  function wireHover(root) {
    (root || document).querySelectorAll('[data-hover]').forEach(function (el) {
      if (el.__hoverWired) return;
      el.__hoverWired = true;
      var decls = el.getAttribute('data-hover').split(';').map(function (d) {
        var i = d.indexOf(':');
        return i < 0 ? null : [d.slice(0, i).trim(), d.slice(i + 1).trim()];
      }).filter(Boolean);
      el.addEventListener('mouseenter', function () {
        decls.forEach(function (d) {
          el.setAttribute('data-h-' + d[0], el.style.getPropertyValue(d[0]));
          el.style.setProperty(d[0], d[1]);
        });
      });
      el.addEventListener('mouseleave', function () {
        decls.forEach(function (d) {
          el.style.setProperty(d[0], el.getAttribute('data-h-' + d[0]) || '');
        });
      });
    });
  }

  /* -------------------------------------------------- navigation */
  function buildNav() {
    var host = document.getElementById('site-nav');
    if (!host) return;

    var dropdown = SITUATIONS.map(function (s) {
      return '<a href="' + s[0] + '" data-hover="background:#ffffff0f;color:#7ACBFF" ' +
        'style="color:#C9D6E8;text-decoration:none;padding:10px 14px;border-radius:9px;font:600 14px \'Manrope\',sans-serif">' +
        s[1] + '</a>';
    }).join('');

    host.innerHTML =
      '<div style="position:sticky;top:0;z-index:80;background:#081426F0;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid #ffffff14">' +
      '<div style="max-width:1240px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:24px;padding:12px 32px">' +
        '<a href="index.html" style="display:flex;align-items:center;gap:12px;text-decoration:none">' +
          '<span style="background:#fff;border-radius:10px;padding:5px 10px;display:flex;align-items:center"><img src="' + LOGO + '" alt="The First Choice Group" style="height:38px;display:block"></span>' +
        '</a>' +
        '<div class="nav-links" style="display:flex;align-items:center;gap:30px;font:600 14.5px \'Manrope\',sans-serif">' +
          '<a href="index.html" data-hover="color:#7ACBFF" style="color:#C9D6E8;text-decoration:none">Home</a>' +
          '<span style="position:relative">' +
            '<span id="nav-sit" data-hover="color:#7ACBFF" style="color:#C9D6E8;cursor:pointer;display:flex;align-items:center;gap:6px">Situations <span style="font-size:10px">&#9660;</span></span>' +
            '<div id="nav-sit-menu" style="display:none;position:absolute;top:34px;left:-12px;background:#0E2240;border:1px solid #ffffff1f;border-radius:14px;padding:8px;flex-direction:column;gap:2px;min-width:230px;box-shadow:0 20px 50px rgba(0,0,0,.5)">' + dropdown + '</div>' +
          '</span>' +
          '<a href="loan-programs.html" data-hover="color:#7ACBFF" style="color:#C9D6E8;text-decoration:none">Loan Programs</a>' +
          '<a href="about.html" data-hover="color:#7ACBFF" style="color:#C9D6E8;text-decoration:none">About</a>' +
          '<a href="contact.html" data-hover="color:#7ACBFF" style="color:#C9D6E8;text-decoration:none">Contact</a>' +
        '</div>' +
        '<a class="nav-cta" href="estimator.html" data-hover="background:#7ACBFF" style="background:#5AB8F5;color:#081426;font:700 14px \'Manrope\',sans-serif;padding:12px 22px;border-radius:11px;text-decoration:none;white-space:nowrap;box-shadow:0 6px 18px rgba(90,184,245,.25)">Get Your Cash Offer</a>' +
        '<span class="nav-toggle" id="nav-toggle" style="width:42px;height:42px;border-radius:10px;background:#ffffff10;align-items:center;justify-content:center;cursor:pointer;color:#C9D6E8;font-size:20px">&#9776;</span>' +
      '</div>' +
      '<div class="mobile-menu" id="mobile-menu" style="flex-direction:column;gap:4px;padding:8px 20px 18px;border-top:1px solid #ffffff12;background:#0B1B33">' +
        mobileLink('index.html', 'Home') +
        '<div style="font:700 11px \'Manrope\',sans-serif;color:#5AB8F5;letter-spacing:.08em;padding:12px 8px 4px">SITUATIONS</div>' +
        SITUATIONS.map(function (s) { return mobileLink(s[0], s[1], true); }).join('') +
        mobileLink('loan-programs.html', 'Loan Programs') +
        mobileLink('about.html', 'About') +
        mobileLink('contact.html', 'Contact') +
        '<a href="estimator.html" style="margin-top:10px;background:#5AB8F5;color:#081426;font:700 14px \'Manrope\',sans-serif;padding:14px;border-radius:11px;text-decoration:none;text-align:center">Get Your Cash Offer</a>' +
      '</div>' +
      '</div>';

    // Situations dropdown (desktop, click to toggle)
    var sit = document.getElementById('nav-sit');
    var sitMenu = document.getElementById('nav-sit-menu');
    var sitOpen = false;
    function setSit(open) { sitOpen = open; sitMenu.style.display = open ? 'flex' : 'none'; }
    sit.addEventListener('click', function (e) { e.stopPropagation(); setSit(!sitOpen); });
    document.addEventListener('click', function () { if (sitOpen) setSit(false); });

    // Mobile menu toggle
    var toggle = document.getElementById('nav-toggle');
    var menu = document.getElementById('mobile-menu');
    toggle.addEventListener('click', function () { menu.classList.toggle('open'); });
  }

  function mobileLink(href, label, indent) {
    return '<a href="' + href + '" data-hover="color:#7ACBFF" style="color:#C9D6E8;text-decoration:none;font:600 15px \'Manrope\',sans-serif;padding:11px ' + (indent ? '18px' : '8px') + '">' + label + '</a>';
  }

  /* -------------------------------------------------- footer */
  function buildFooter() {
    var host = document.getElementById('site-footer');
    if (!host) return;

    var link = function (href, label) {
      return '<a href="' + href + '" data-hover="color:#7ACBFF" style="font:500 14px \'Manrope\',sans-serif;color:#8DA0BC;text-decoration:none">' + label + '</a>';
    };
    var social = function (t) {
      return '<span data-hover="background:#5AB8F5;color:#081426" style="width:36px;height:36px;border-radius:10px;background:#ffffff10;display:flex;align-items:center;justify-content:center;color:#C9D6E8;font:700 13px \'Manrope\',sans-serif;cursor:pointer">' + t + '</span>';
    };

    host.innerHTML =
      '<div style="background:#050E1C;border-top:1px solid #ffffff12">' +
      '<div class="cols pad-sec" style="max-width:1240px;margin:0 auto;padding:64px 32px 32px;grid-template-columns:minmax(0,1.5fr) repeat(3,minmax(0,1fr));gap:48px">' +
        '<div style="display:flex;flex-direction:column;gap:16px">' +
          '<span style="background:#fff;border-radius:10px;padding:6px 12px;align-self:flex-start"><img src="' + LOGO + '" alt="The First Choice Group" style="height:36px;display:block"></span>' +
          '<div style="font:500 14px/1.7 \'Manrope\',sans-serif;color:#8DA0BC;max-width:320px">A professional real estate solutions and redevelopment company. Cash offers for sellers, capital for investors — built on People, Service, and Integrity.</div>' +
          '<div style="font:700 12px \'Manrope\',sans-serif;color:#5AB8F5;letter-spacing:.08em">WHEREVER YOUR PROPERTY IS &mdash; WE&rsquo;LL MAKE AN OFFER</div>' +
          '<div style="display:flex;gap:10px">' + social('f') + social('in') + social('ig') + social('✕') + '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:12px">' +
          '<div style="font:700 13px \'Sora\',sans-serif;color:#fff;letter-spacing:.06em;margin-bottom:4px">SOLUTIONS</div>' +
          link('just-selling.html', 'Just Looking to Sell') +
          link('foreclosure.html', 'Facing Foreclosure') +
          link('repairs.html', 'Too Many Repairs') +
          link('probate.html', 'Inherited &amp; Probate') +
          link('relocation.html', 'Relocation &amp; Divorce') +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:12px">' +
          '<div style="font:700 13px \'Sora\',sans-serif;color:#fff;letter-spacing:.06em;margin-bottom:4px">COMPANY</div>' +
          link('about.html', 'About Us') +
          link('loan-programs.html', 'Loan Programs') +
          link('contact.html', 'Contact') +
          link('faq.html', 'Common Questions') +
          link('estimator.html', 'Instant Offer Estimator') +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:14px">' +
          '<div style="font:700 13px \'Sora\',sans-serif;color:#fff;letter-spacing:.06em;margin-bottom:4px">GET STARTED</div>' +
          '<div style="font:500 13px/1.6 \'Manrope\',sans-serif;color:#8DA0BC">Your no-obligation cash offer is one address away.</div>' +
          '<a href="estimator.html" data-hover="background:#7ACBFF;color:#081426" style="background:#5AB8F5;color:#081426;font:700 14px \'Manrope\',sans-serif;padding:13px 20px;border-radius:11px;text-decoration:none;text-align:center">Get Your Cash Offer</a>' +
          '<div style="display:flex;align-items:center;gap:8px;font:600 12px \'Manrope\',sans-serif;color:#8DA0BC"><span style="background:#00548F;color:#fff;font:800 11px \'Sora\',sans-serif;padding:4px 7px;border-radius:4px;letter-spacing:.02em">BBB</span> A+ Accredited Business</div>' +
        '</div>' +
      '</div>' +
      '<div class="pad-sec" style="max-width:1240px;margin:0 auto;padding:24px 32px;border-top:1px solid #ffffff0f;display:flex;justify-content:space-between;gap:24px;flex-wrap:wrap">' +
        '<div style="font:500 12.5px \'Manrope\',sans-serif;color:#5F7392">&copy; 2026 The First Choice Group. All rights reserved.</div>' +
        '<div style="font:500 12.5px \'Manrope\',sans-serif;color:#5F7392">Offer estimates are preliminary and subject to property review. Not a lender in all states.</div>' +
      '</div>' +
      '</div>';
  }

  /* -------------------------------------------------- chat widget */
  function chatAnswer(q) {
    var t = q.toLowerCase();
    if (/fee|commission|cost|charge/.test(t)) return "Zero. No commissions, no fees, and we pay all closing costs. The offer you accept is the amount you walk away with — we can put that in writing.";
    if (/foreclos/.test(t)) return "We help sellers in pre-foreclosure all the time. Because we buy in cash with no financing contingencies, we can often close before an auction date — sometimes in as little as 10 days. Want me to start a no-obligation offer for your property?";
    if (/probate|inherit|estate/.test(t)) return "Inherited properties are one of our specialties. We coordinate with your probate attorney, buy fully as-is (belongings can stay), and time the closing around the court process. No cleanout needed.";
    if (/repair|as.?is|condition|fix|damage|old/.test(t)) return "We buy 100% as-is — fire damage, code violations, decades of deferred maintenance, all of it. You never make a repair or even clean. Our offer already accounts for condition.";
    if (/how (fast|long)|close|timeline|days|quick/.test(t)) return "Our average is 26 days from offer to closing, and we can move as fast as 10 days when needed. You pick the date — we work around your timeline, not the other way around.";
    if (/worth|value|offer|estimate|price|much/.test(t)) return "Our instant estimator can give you a preliminary cash-offer range in about 60 seconds — just enter your address and answer a few quick questions. Tap 'Get Your Cash Offer' at the top of the page to start.";
    if (/loan|lend|flip|invest|rehab|financ|rate/.test(t)) return "For investors we offer fix-and-flip loans up to 90% of purchase and 100% of rehab, plus bridge financing. Check the Loan Programs page, or I can have a loan specialist call you.";
    if (/agent|realtor|list/.test(t)) return "Unlike listing with an agent: no 6% commission, no showings, no appraisal or financing contingencies, and no 90-day wait. If a traditional listing is genuinely your better option, we'll tell you that too.";
    if (/scam|legit|trust|real/.test(t)) return "Fair question. We're a BBB A+ accredited business with a 4.9★ Google rating across 300+ reviews, and 1,300+ homeowners helped. Happy to share references before you commit to anything.";
    if (/call|talk|human|person|phone/.test(t)) return "Of course — a real specialist (not a bot) can call you within one business hour. Just head to the Contact page and leave your number, or share it here.";
    return "Great question — here's the short version: we make no-obligation cash offers, buy fully as-is, charge zero fees, and close on your date. Could you share your property's city and state so I can point you to the right next step?";
  }

  function buildChat() {
    var host = document.createElement('div');
    host.id = 'site-chat';
    document.body.appendChild(host);

    var state = {
      open: false,
      typing: false,
      msgs: [{ who: 'ai', text: "Hi, I'm the First Choice AI assistant. I can answer questions about selling your house for cash, timelines, fees, or investor financing — 24/7. What's on your mind?" }]
    };
    var scrollEl;

    function esc(s) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

    function render() {
      var chips = state.msgs.length <= 2
        ? ["How fast can you close?", "Do you charge fees?", "I'm facing foreclosure", "What's my house worth?"]
        : [];

      var msgHtml = state.msgs.map(function (m) {
        var ai = m.who === 'ai';
        var justify = ai ? 'flex-start' : 'flex-end';
        var bg = ai ? '#ffffff12' : '#5AB8F5';
        var color = ai ? '#DCE6F4' : '#081426';
        var radius = ai ? '14px 14px 14px 4px' : '14px 14px 4px 14px';
        return '<div style="display:flex;justify-content:' + justify + '">' +
          '<div style="max-width:82%;padding:11px 14px;border-radius:' + radius + ';background:' + bg + ';color:' + color + ';font:500 13.5px/1.55 \'Manrope\',sans-serif;white-space:pre-line">' + esc(m.text) + '</div></div>';
      }).join('');

      if (state.typing) {
        msgHtml += '<div style="align-self:flex-start;background:#ffffff12;border-radius:14px 14px 14px 4px;padding:12px 16px;color:#8DA0BC;font:600 13px \'Manrope\',sans-serif;letter-spacing:2px">&bull;&bull;&bull;</div>';
      }

      var chipsHtml = chips.map(function (c, i) {
        return '<span data-chip="' + i + '" data-hover="background:#5AB8F51f" style="border:1px solid #5AB8F566;color:#7ACBFF;font:600 11.5px \'Manrope\',sans-serif;padding:6px 11px;border-radius:999px;cursor:pointer">' + esc(c) + '</span>';
      }).join('');

      var panel = state.open ?
        '<div style="width:370px;max-width:calc(100vw - 32px);height:520px;max-height:calc(100vh - 120px);background:#0E2240;border:1px solid #ffffff1f;border-radius:20px;box-shadow:0 30px 80px rgba(0,0,0,.55);display:flex;flex-direction:column;overflow:hidden">' +
          '<div style="padding:16px 18px;background:#0B1B33;border-bottom:1px solid #ffffff14;display:flex;align-items:center;gap:12px">' +
            '<span style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#5AB8F5,#37C8E0);display:flex;align-items:center;justify-content:center;font:800 15px \'Sora\',sans-serif;color:#081426">&#9672;</span>' +
            '<span style="display:flex;flex-direction:column;gap:2px">' +
              '<span style="font:700 14px \'Sora\',sans-serif;color:#fff">First Choice AI</span>' +
              '<span style="display:flex;align-items:center;gap:6px;font:600 11px \'Manrope\',sans-serif;color:#2EC98E"><span style="width:6px;height:6px;border-radius:50%;background:#2EC98E"></span>Online 24/7</span>' +
            '</span>' +
            '<span id="chat-close" data-hover="color:#fff" style="margin-left:auto;color:#8DA0BC;cursor:pointer;font:600 18px \'Manrope\',sans-serif;padding:4px 8px">&times;</span>' +
          '</div>' +
          '<div id="chat-scroll" style="flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px">' + msgHtml + '</div>' +
          '<div style="padding:10px 14px 6px;display:flex;gap:8px;flex-wrap:wrap">' + chipsHtml + '</div>' +
          '<div style="padding:12px 14px 14px;display:flex;gap:8px">' +
            '<input id="chat-input" placeholder="Ask anything about selling…" style="flex:1;background:#081426;border:1px solid #ffffff1f;border-radius:11px;padding:12px 14px;color:#fff;font:500 13.5px \'Manrope\',sans-serif;outline:none">' +
            '<span id="chat-send" data-hover="background:#7ACBFF" style="background:#5AB8F5;color:#081426;border-radius:11px;padding:12px 16px;font:700 13px \'Manrope\',sans-serif;cursor:pointer">&uarr;</span>' +
          '</div>' +
        '</div>' : '';

      host.innerHTML =
        '<div style="position:fixed;bottom:24px;right:24px;z-index:100;display:flex;flex-direction:column;align-items:flex-end;gap:14px;font-family:\'Manrope\',sans-serif">' +
          panel +
          '<div id="chat-fab" data-hover="transform:scale(1.06)" style="width:58px;height:58px;border-radius:50%;background:linear-gradient(135deg,#5AB8F5,#37C8E0);display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 14px 40px rgba(90,184,245,.4);font:800 22px \'Sora\',sans-serif;color:#081426">' + (state.open ? '&times;' : '&#9672;') + '</div>' +
        '</div>';

      wireHover(host);

      document.getElementById('chat-fab').addEventListener('click', function () {
        state.open = !state.open; render(); scrollDown();
      });
      if (state.open) {
        document.getElementById('chat-close').addEventListener('click', function () { state.open = false; render(); });
        var input = document.getElementById('chat-input');
        var send = function () { doSend(input.value); };
        document.getElementById('chat-send').addEventListener('click', send);
        input.addEventListener('keydown', function (e) { if (e.key === 'Enter') send(); });
        host.querySelectorAll('[data-chip]').forEach(function (c) {
          c.addEventListener('click', function () { doSend(chips[+c.getAttribute('data-chip')]); });
        });
        scrollEl = document.getElementById('chat-scroll');
        scrollDown();
      }
    }

    function scrollDown() {
      setTimeout(function () { if (scrollEl) scrollEl.scrollTop = scrollEl.scrollHeight; }, 30);
    }

    function doSend(text) {
      var q = (text || '').trim();
      if (!q || state.typing) return;
      state.msgs.push({ who: 'me', text: q });
      state.typing = true;
      render(); scrollDown();
      setTimeout(function () {
        state.msgs.push({ who: 'ai', text: chatAnswer(q) });
        state.typing = false;
        render(); scrollDown();
      }, 900);
    }

    render();
  }

  /* -------------------------------------------------- boot */
  function init() {
    buildNav();
    buildFooter();
    buildChat();
    wireHover(document);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // expose for page scripts that inject markup later
  window.FCG = { wireHover: wireHover };
})();
